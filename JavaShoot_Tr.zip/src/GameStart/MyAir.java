package GameStart;

import GameStart.GameRoom.MyCanvas;

public class MyAir {
	int x = 200;
	int y = 420;
	
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = this.x + x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = this.y + y;
	}
	
	
}
